import javax.swing.JFrame;

public class Canvas extends JFrame {
    public Canvas(int width, int height) {
        this.setSize(500, 500);
    }
}
